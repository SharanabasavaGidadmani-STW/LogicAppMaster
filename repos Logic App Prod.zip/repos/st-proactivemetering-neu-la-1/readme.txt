
Update Path vaules based on environment.

"path": "/v2/datasets/@{encodeURIComponent(encodeURIComponent('st-proactivemetering-prod-neu-sqlserver.database.windows.net'))},@{encodeURIComponent(encodeURIComponent('st-proactivemetering-prod-sqldb'))}/query/sql"

Like 
For Prod 
Server:- st-proactivemetering-prod-neu-sqlserver.database.windows.net
DB Name : st-proactivemetering-prod-sqldb

For Pre Prod
Server:- st-proactivemetering-preprod-neu-sqlserver.database.windows.net
DB Name =st-proactivemetering-preprod-sqldb